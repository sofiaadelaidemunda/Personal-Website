# Blog Stories Part 2

A Pen created on CodePen.

Original URL: [https://codepen.io/SOFIA-ADELAIDE-MUNDA/pen/raLjMvR](https://codepen.io/SOFIA-ADELAIDE-MUNDA/pen/raLjMvR).

