# Blog Stories Part 3

A Pen created on CodePen.

Original URL: [https://codepen.io/SOFIA-ADELAIDE-MUNDA/pen/gbMooev](https://codepen.io/SOFIA-ADELAIDE-MUNDA/pen/gbMooev).

